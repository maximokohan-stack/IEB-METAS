# IEB+ Metas — prototipo v3

Prototipo navegable de **IEB+ Metas**: una sección dentro de la app IEB+ para que universitarios de 18 a 24 años conviertan una meta personal en un plan de inversión.

## Abrir

- **`index.html`**: versión autocontenida. Se abre con doble clic, funciona sin internet.
- **`src/metas-v3.dc.html`**: código fuente. Necesita servirse desde un servidor local (por ejemplo `npx serve src`) porque carga `support.js` y el design system de `src/_ds/`.

## Recorrido

1. **Objetivo**: qué querés lograr, cuánto, para cuándo, cuánto invertís hoy, cuánto aportás por mes y disponibilidad.
2. **Entender**: experiencia, reacción ante una baja y nivel de riesgo.
3. **Elegir**: tres opciones por riesgo, una sugerida con su porqué, comparación, glosario y simulación.
4. **Invertir**: plan IEB+ (Rookie / Investor), forma de aporte y confirmación.
5. **Seguir**: progreso, "Tu estrategia hoy", avisos, aprendizaje y adaptación del plan.

El panel de prueba a la derecha permite saltar a cada etapa, forzar estados (fuera de ritmo, mercado malo, nueva revisión) y ver los eventos de métricas.

## Nota

Montos, fondos y composiciones son ficticios. Las proyecciones usan una estimación simple, no datos de IEB Research.
